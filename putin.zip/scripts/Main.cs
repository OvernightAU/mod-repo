﻿using System.Collections;
using System;
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;
using UnityObject = UnityEngine.Object;
using Kino;
using Hazel;
using System.Linq;
using TMPro;
using System.Collections.Generic;

public class DynamicCode
{
    private VideoPlayer videoPlayer;

    public void Execute()
    {
        Sprite sovietSprite = ImageUtils.LoadNewSprite(ModsManager.Instance.GetPathFromMod(Paths.folderName, "resources/images/soviet.png"), 100f, SpriteMeshType.FullRect);
        RoleManager.Instance.AddSprite("sovietSprite", sovietSprite.texture, 360f);

        RoleManager.Instance.AddRole<MoscowRole>();

        if (SceneManager.GetActiveScene().name == "MainMenu")
        {
            AddWaterMrk();
        }

		SceneManager.activeSceneChanged += delegate(Scene oldScene, Scene scene)
		{
            if (scene.name == "MainMenu")
            {
                AddWaterMrk();
            }
		};
    }

    internal void AddWaterMrk()
    {
        Coroutines.Instance.StartCoroutine(AddWaterMrkCoroutine());
    }

    private IEnumerator AddWaterMrkCoroutine()
    {
        yield return new WaitForSeconds(0.05f); // Wait for code execution

        GameObject.Find("VersionShower").GetComponent<TextMeshPro>().text += "\n<size=350%><sprite=10></size>";

        videoPlayer = new GameObject("vp").AddComponent<VideoPlayer>();
        videoPlayer.source = VideoSource.Url;
        videoPlayer.url = ModsManager.Instance.GetPathFromMod(Paths.folderName, "resources/video/cutscene.mp4");
        videoPlayer.Prepare();
        videoPlayer.prepareCompleted += VideoPrepared;
    }

    void VideoPrepared(VideoPlayer vp)
    {
        GameObject quad = GameObject.CreatePrimitive(PrimitiveType.Quad);
        quad.transform.parent = GameObject.Find("vp").transform;
        quad.transform.localPosition = Vector3.zero;
        quad.transform.localRotation = Quaternion.identity;
        quad.transform.localScale = new Vector3(16f, 9f, 1f); // Assuming 16:9 aspect ratio

        Renderer renderer = quad.GetComponent<Renderer>();
        Material material = new Material(Shader.Find("Unlit/Texture"));
        material.mainTexture = vp.texture;
        renderer.material = material;

        vp.targetTexture = new RenderTexture(Screen.width, Screen.height, 24);
        vp.renderMode = VideoRenderMode.RenderTexture;
        vp.targetCamera = Camera.main;

        vp.Play();
    }
}