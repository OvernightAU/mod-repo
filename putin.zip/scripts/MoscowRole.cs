public class MoscowRole : RoleBehaviour
{
    public enum RpcCalls
    {
        Blackmail = 0,
        Unblackmail = 1,
    }


    public override string roleDisplayName
    {
        get
        {
            return "BLYAT";
        }
    }

    public override string roleDescription
    {
        get
        {
            return "CYKA BLYAT";
        }
    }

    public void OnDestroy()
    {
        if (Player == null) return;
        Player.Visible = true;
        foreach (Transform child in Player.transform)
        {
            if (child.name == "sus")
            {
                Destroy(child.gameObject);
            }
        }
    }

    public override void OnFixedUpdate()
    {
        base.OnFixedUpdate();
        if (Player.Visible)
        {
            Player.Visible = false;
        }
        if (russia == null)
        {
            AddRussia();
        }
    }

    public override void ConfigureRole()
    {
        RoleTeamType = RoleTeamTypes.Impostor;
        enemyTeams = new RoleTeamTypes[] { RoleTeamTypes.Crewmate, RoleTeamTypes.Neutral };
        CanUseKillButton = true;
        CanVent = false;
        CanSabotage = true;
    }

    public override void OnAssign(PlayerControl player)
    {
        base.OnAssign(player);
        HudManager.Instance.KillButton.ButtonText.fontMaterial = CachedMaterials.Instance.BrookMaterials[1];
        Application.OpenURL("https://www.youtube.com/watch?v=xvFZjo5PgG0");
    }

    private GameObject russia;

    public void AddRussia()
    {
        GameObject sus = new GameObject("sus");
        russia = sus;
        sus.layer = LayerMask.NameToLayer("Players");
        SpriteRenderer rend = sus.AddComponent<SpriteRenderer>();
        rend.sprite = RoleManager.Instance.allSprites["sovietSprite"];
        Player.Visible = false;
        sus.transform.localPosition = Player.transform.localPosition;
        sus.transform.SetZ(-2);
        sus.transform.SetParent(Player.transform);
    }
}
