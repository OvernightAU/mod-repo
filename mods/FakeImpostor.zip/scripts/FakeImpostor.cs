public class FakeImpostorRole : RoleBehaviour
{
    public override string roleDescription
    {
        get
        {
            string lang = TranslationController.Instance.CurrentLanguage.langName;
            if (lang == "Portugu�s") return "Voc� pode usar dutos.";
            return "You are Fake Impostor";
        }
    }

    public override string roleDisplayName
    {
        get
        {
            string lang = TranslationController.Instance.CurrentLanguage.langName;
            if (lang == "Portugu�s") return "Engenheiro";
            return "Fake Impostor";
        }
    }

    public override void ConfigureRole()
    {
        RoleTeamType = RoleTeamTypes.Impostor;
        enemyTeams = new RoleTeamTypes[] { RoleTeamTypes.Crewmate, RoleTeamTypes.Impostor };
        CanUseKillButton = false;
        CanVent = true;
    }
}
