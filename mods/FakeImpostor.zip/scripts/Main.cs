using System.Collections;
using System;
using UnityEngine;

public class DynamicCode
{


    public void Execute()
   {
RoleManager.Instance.AddRole<FakeImpostorRole>();
    }

}
