﻿using UnityEngine;
using System;
using System.Collections.Generic;

public class DynamicCode
{
    // In front defines if your hat will overlay the player or be behind him
    // Main image is the path for the sprite

    // Change this to add hats

    private List<HatData> hatList = new List<HatData>
    {
        new HatData { InFront = true, Size = 0.5f , ProductId = "Sans", MainImagePath = "resources/images/hdog.png", Offset = new Vector2 (0, -0.25f) },
        new HatData { InFront = true, Size = 1.3f , ProductId = "Stupid", MainImagePath = "resources/images/diss.png", Offset = Vector2.zero },
    };


    //--BELOW ONLY FOR ADVANCED USERS--ONLY CHANGE THIS IF YOU KNOW WHAT YOU'RE DOING.--//
    public class HatData
    {
        public bool InFront { get; set; }
        public float Size { get; set; }
        public string ProductId { get; set; }
        public string MainImagePath { get; set; }
        public Vector2 Offset { get; set; }
    }
    public void Execute()
    {
        foreach (var hatData in hatList)
        {
            // Load the sprite from the image path
            Sprite mainImage = LoadSpriteCustom(ModsManager.Instance.GetPathFromMod(Paths.folderName, hatData.MainImagePath), 300f / hatData.Size, SpriteMeshType.FullRect, hatData.Offset);

            // Add the hat with the loaded sprite
            AddHat(hatData.ProductId, mainImage, hatData.InFront);
        }
    }

    public static void AddHat(string prodId, Sprite mainImage, bool inFront)
    {
        HatBehaviour hat = new HatBehaviour
        {
            InFront = inFront,
            MainImage = mainImage,
            FloorImage = mainImage,
            ProductId = prodId,
            StoreName = "",
        };
        HatManager.Instance.AllHats.Add(hat);
    }

    public static Sprite LoadSpriteCustom(string FilePath, float PixelsPerUnit, SpriteMeshType spriteType, Vector2 Offset)
    {
        // Load a PNG or JPG image from disk to a Texture2D, assign this texture to a new sprite and return its reference
        Texture2D SpriteTexture = ImageUtils.LoadTexture(FilePath);
        Rect rect = new Rect(0, 0, SpriteTexture.width, SpriteTexture.height);
        Vector2 pivot = new Vector2(0.5f + Offset.x, 0.5f + -Offset.y);
        Sprite NewSprite = Sprite.Create(SpriteTexture, rect, pivot, PixelsPerUnit, 0, spriteType);
        return NewSprite;
    }
}