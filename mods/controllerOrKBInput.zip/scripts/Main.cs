﻿using System.Collections;
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityObject = UnityEngine.Object;
using Hazel;
using System.Linq;
using TMPro;
using System.Collections.Generic;
using LevelImposter;
using System.Runtime.InteropServices;
using LevelImposter.Api;
using System.IO;
using InnerNet;
using Rewired;

public class DynamicCode
{
    public void Execute()
    {
        if (!DestroyableSingleton<ModsManager>.InstanceExists) return;

        var joystickManager = new GameObject("sus");
        joystickManager.AddComponent<ControllerJoystick>();
        UnityObject.DontDestroyOnLoad(joystickManager);
    }
}