﻿public class ControllerJoystick : MonoBehaviour, IVirtualJoystick
{
    private Vector2 del;
    private Player player; // Rewired player instance
    private Joystick currentJoystick; // Reference to the current joystick

    public Vector2 Delta => del;

    public enum PS4Button
    {
        Cross = 0,
        Circle = 1,
        Square = 2,
        Triangle = 3,
        L1 = 4,
        R1 = 5,
        L2 = 6,
        R2 = 7,
        PS = 8,
        Touchpad = 9,
        L3 = 10,
        R3 = 11,
        DPadUp = 12,
        DPadDown = 13,
        DPadLeft = 14,
        DPadRight = 15,
        Other1 = 16,
        Other2 = 17,
    }

    public enum XboxButton
    {
        A = 0,
        B = 1,
        X = 2,
        Y = 3,
        LB = 4,
        RB = 5,
        LT = 6,
        RT = 7,
        Start = 8,
        Select = 9,
        L3 = 10,
        R3 = 11,
        DPadUp = 12,
        DPadDown = 13,
        DPadLeft = 14,
        DPadRight = 15,
    }

    private void FixedUpdate()
    {
        // Initialize Rewired Player
        player = ReInput.players.GetPlayer(0); // Get the first player

        if (currentJoystick == null)
        {
            currentJoystick = FindJoystick();
            if (currentJoystick != null)
            {
                Debug.LogWarning("Joystick found.");
            }
        }
    }

    private Joystick FindJoystick()
    {
        // Look for a connected joystick
        foreach (var joystick in ReInput.controllers.Joysticks)
        {
            if (joystick.name.ToLower().Contains("ps4") || joystick.name.ToLower().Contains("dualshock") ||
                joystick.name.ToLower().Contains("xbox") || joystick.name.ToLower().Contains("xinput"))
            {
                return (Joystick)joystick; // Cast to Joystick type
            }
        }
        return null; // No supported controller found
    }

    private void Update()
    {
        if (!PlayerControl.LocalPlayer)
        {
            return;
        }

        // Ensure the correct joystick is active
        SetAsCurrentJoystickIfNot();

        // Reset delta
        del.x = del.y = 0f;

        if (currentJoystick == null)
        {
            HandleKeyboardInput();
        }
        else
        {
            HandleInputDirect();
        }

        // Normalize delta to keep input consistent
        del.Normalize();
    }

    private void SetAsCurrentJoystickIfNot()
    {
        if (DestroyableSingleton<HudManager>.InstanceExists &&
            DestroyableSingleton<HudManager>.Instance.joystick != this)
        {
            if (DestroyableSingleton<HudManager>.Instance.joystick != null &&
                DestroyableSingleton<HudManager>.Instance.joystick is MonoBehaviour oldJoystick)
            {
                UnityObject.Destroy(oldJoystick.gameObject);
            }

            DestroyableSingleton<HudManager>.Instance.joystick = this;
        }
    }


    private void HandleKeyboardInput()
    {
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            del.x += 1f;
        }
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            del.x -= 1f;
        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {
            del.y += 1f;
        }
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        {
            del.y -= 1f;
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            DestroyableSingleton<HudManager>.Instance.ReportButton.DoClick();
        }
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.E))
        {
            DestroyableSingleton<HudManager>.Instance.UseButton.DoClick();
        }
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            DestroyableSingleton<HudManager>.Instance.ShowMap(m => m.ShowNormalMap());
        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            DestroyableSingleton<HudManager>.Instance.KillButton.PerformKill();
        }
        if (Input.GetKeyDown(KeyCode.V))
        {
            PlayerControl.LocalPlayer.closestVent?.Use();
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if ((bool)Minigame.Instance)
            {
                Minigame.Instance.Close();
            }
            else if (DestroyableSingleton<HudManager>.InstanceExists && (bool)MapBehaviour.Instance && MapBehaviour.Instance.IsOpen)
            {
                MapBehaviour.Instance.Close();
            }
            else if ((bool)CustomPlayerMenu.Instance)
            {
                CustomPlayerMenu.Instance.Close();
            }
        }
    }

    private void HandleInputDirect()
    {
        // Axis IDs (replace these with your actual setup)
        const int horizontalAxisId = 0; // Move Horizontal
        const int verticalAxisId = 1;   // Move Vertical
        const int rightHorizontalAxisId = 2; // Right Stick Horizontal
        const int rightVerticalAxisId = 3;   // Right Stick Vertical

        float horizontal = currentJoystick.GetAxis(horizontalAxisId);
        float vertical = currentJoystick.GetAxis(verticalAxisId);

        // Deadzone handling
        float deadzone = 0.2f;
        if (Mathf.Abs(horizontal) > deadzone)
        {
            del.x += horizontal;
        }
        if (Mathf.Abs(vertical) > deadzone)
        {
            del.y += vertical;
        }

        // Check if it's a PS4 controller
        if (currentJoystick.name.ToLower().Contains("ps4") || currentJoystick.name.ToLower().Contains("dualshock"))
        {
            HandlePS4Input();
        }
        // Check if it's an Xbox controller
        else if (currentJoystick.name.ToLower().Contains("xbox") || currentJoystick.name.ToLower().Contains("xinput"))
        {
            HandleXboxInput();
        }
        else
        {
            HandleKeyboardInput();
        }

        HandleMouseMovement(currentJoystick.GetAxis(rightHorizontalAxisId), currentJoystick.GetAxis(rightVerticalAxisId));
    }


    private void HandleMouseMovement(float rightHorizontal, float rightVertical)
    {
        // Move mouse position
        float mouseSpeed = 7f; // Adjust sensitivity
        MouseOperations.MousePoint currentPos;
        MouseOperations.GetCursorPos(out currentPos);

        int newX = currentPos.X + (int)(rightHorizontal * mouseSpeed);
        int newY = currentPos.Y - (int)(rightVertical * mouseSpeed);

        MouseOperations.SetCursorPos(newX, newY);

        if (currentJoystick.GetButtonDown((int)PS4Button.R3) || currentJoystick.GetButtonDown((int)XboxButton.Select))
        {
            MouseOperations.Hold();
        }

        if (currentJoystick.GetButtonUp((int)PS4Button.R3) || currentJoystick.GetButtonUp((int)XboxButton.Select))
        {
            MouseOperations.Release();
        }
    }

    private void HandlePS4Input()
    {
        if (currentJoystick.GetButtonDown((int)PS4Button.Cross))
        {
            DestroyableSingleton<HudManager>.Instance.UseButton.DoClick();
        }
        if (currentJoystick.GetButtonDown((int)PS4Button.Circle))
        {
            DestroyableSingleton<HudManager>.Instance.ReportButton.DoClick();
        }
        if (currentJoystick.GetButtonDown((int)PS4Button.Square))
        {
            DestroyableSingleton<HudManager>.Instance.KillButton.PerformKill();
        }
        if (currentJoystick.GetButtonDown((int)PS4Button.R1))
        {
            DestroyableSingleton<HudManager>.Instance.ShowMap(m => m.ShowNormalMap());
        }
        if (currentJoystick.GetButtonDown((int)PS4Button.Other1))
        {
            var options = DestroyableSingleton<HudManager>.Instance.GameMenu.gameObject;
            options.SetActive(!options.activeSelf);
        }

        if (currentJoystick.GetButtonDown((int)PS4Button.Circle))  // Circle button (O) - replace with the correct button ID
        {
            if (Minigame.Instance)
            {
                Minigame.Instance.Close();
            }
            else if (DestroyableSingleton<HudManager>.InstanceExists &&
                     MapBehaviour.Instance && MapBehaviour.Instance.IsOpen)
            {
                MapBehaviour.Instance.Close();
            }
            else if (CustomPlayerMenu.Instance)
            {
                CustomPlayerMenu.Instance.Close();
            }
        }
    }

    private void HandleXboxInput()
    {
        if (currentJoystick.GetButtonDown((int)XboxButton.A))
        {
            DestroyableSingleton<HudManager>.Instance.UseButton.DoClick();
        }
        if (currentJoystick.GetButtonDown((int)XboxButton.B))
        {
            DestroyableSingleton<HudManager>.Instance.ReportButton.DoClick();
        }
        if (currentJoystick.GetButtonDown((int)XboxButton.X))
        {
            DestroyableSingleton<HudManager>.Instance.KillButton.PerformKill();
        }
        if (currentJoystick.GetButtonDown((int)XboxButton.RB))
        {
            DestroyableSingleton<HudManager>.Instance.ShowMap(m => m.ShowNormalMap());
        }
        if (currentJoystick.GetButtonDown((int)XboxButton.Select))
        {
            var options = DestroyableSingleton<HudManager>.Instance.GameMenu.gameObject;
            options.SetActive(!options.activeSelf);
        }

        if (currentJoystick.GetButtonDown((int)XboxButton.B))  // Circle button (O) - replace with the correct button ID
        {
            if (Minigame.Instance)
            {
                Minigame.Instance.Close();
            }
            else if (DestroyableSingleton<HudManager>.InstanceExists &&
                     MapBehaviour.Instance && MapBehaviour.Instance.IsOpen)
            {
                MapBehaviour.Instance.Close();
            }
            else if (CustomPlayerMenu.Instance)
            {
                CustomPlayerMenu.Instance.Close();
            }
        }
    }
}
