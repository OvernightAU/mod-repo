[HarmonyPatch(typeof(HudManager))]
public class Zoom
{
    private static bool ResetButtons = false;
    private static float previousPinchDistance;
    public static bool CanMove
    {
        get
        {
            if (PlayerControl.LocalPlayer == null) return false;
            else return PlayerControl.LocalPlayer.CanMove;
        }
    }
    private static readonly float zoomSpeed = 60f;

    [HarmonyPatch(typeof(HudManager), "Update")]
    [HarmonyPostfix]
    public static void Postfix()
    {
        if (CanMove && AmongUsClient.Instance.AmHost)
        {
            if (Camera.main.orthographicSize > 3f)
                ResetButtons = true;

            if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
            {
                HandlePinchZoom();
            }
            else
            {
                HandleScrollZoom();
            }
        }
        else
        {
            SetZoomSize(reset: true);
        }

        if (!HudManager.InstanceExists) return;

        bool isUhh = Camera.main.orthographicSize < 3.01f;

        DestroyableSingleton<HudManager>.Instance.ShadowQuad.gameObject.SetActive(isUhh && !PlayerControl.LocalPlayer.Data.IsDead);
    }

    private static void HandleScrollZoom()
    {
        if (Input.mouseScrollDelta.y > 0)
        {
            if (Camera.main.orthographicSize > 3.0f)
            {
                SetZoomSize(times: false);
            }
        }
        if (Input.mouseScrollDelta.y < 0)
        {
            if (Camera.main.orthographicSize < 18.0f)
            {
                SetZoomSize(times: true);
            }
        }
    }

    private static void HandlePinchZoom()
    {
        if (Input.touchCount >= 3)
        {
            // Get the positions of the first two fingers
            Touch touch0 = Input.GetTouch(0);
            Touch touch1 = Input.GetTouch(1);

            // Calculate the pinch zoom
            Vector2 touch0PrevPos = touch0.position - touch0.deltaPosition;
            Vector2 touch1PrevPos = touch1.position - touch1.deltaPosition;

            float prevTouchDeltaMag = (touch0PrevPos - touch1PrevPos).magnitude;
            float touchDeltaMag = (touch0.position - touch1.position).magnitude;

            float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

            if (deltaMagnitudeDiff != 0)
            {
                float targetSize = Mathf.Clamp(Camera.main.orthographicSize + deltaMagnitudeDiff * Time.deltaTime, 3f, 18f);
                Camera.main.orthographicSize = targetSize;
                HudManager.Instance.UICamera.orthographicSize = targetSize;
            }
        }
    }



    private static void SetZoomSize(bool times = false, bool reset = false)
    {
        var size = 1.5f;
        if (!times) size = 1 / size; // Correcting the logic here
        if (reset)
        {
            Camera.main.orthographicSize = 3.0f;
            HudManager.Instance.UICamera.orthographicSize = 3.0f;
            HudManager.Instance.Chat.transform.localScale = Vector3.one;
        }
        else
        {
            float targetSize = Mathf.Clamp(Camera.main.orthographicSize + (Input.mouseScrollDelta.y > 0 ? -1f : 1f), 3f, 18f);
            float easedSize = EaseInOutQuad(Camera.main.orthographicSize, targetSize, zoomSpeed * Time.deltaTime);
            Camera.main.orthographicSize = easedSize;
            HudManager.Instance.UICamera.orthographicSize = easedSize;
        }

        if (ResetButtons)
        {
            ResolutionManager.InvokeResolutionChanged();
            ResetButtons = false;
        }
    }

    private static float EaseInOutQuad(float start, float end, float value)
    {
        value /= 0.5f;
        end -= start;
        if (value < 1) return end / 2 * value * value + start;
        value--;
        return -end / 2 * (value * (value - 2) - 1) + start;
    }
}
