role = {
    codeName = "AssassinRole",
    name = "Assassin",
    description = "Kills a random player when a meeting is called",
    team = "Neutral",
    canVent = true,

    onMeetingCalled = function(self, player)
        print("Meeting called — time to kill someone!")

        local playersWrapper = GetAllPlayers()
        if playersWrapper == nil or playersWrapper.Count == 0 then
            print("No players to kill!")
            return
        end

        -- Pick a random target
        local idx = math.random(1, playersWrapper.Count)
        local target = playersWrapper:Get(idx)
        
        -- Call the RPC to murder the player
        player:RpcMurderPlayer(target, 1)
        print("Murdered player: " .. target.name)
    end,

    onAssign = function(self, player)
        print("Role assigned!")
        player.MyPhysics.SetBodyType(1)
    end
}