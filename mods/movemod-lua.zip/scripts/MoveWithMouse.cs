﻿public class MoveWithMouse : MonoBehaviour
{
    private Object selectedPlayer;
    private bool isDragging;
    private readonly EasyInterval tpInterval = new EasyInterval(0.022f, UpdateType.Default);
    private int activeTouchId = -1;

    private float lastPlayerScale = 0.7f;

    public void Update()
    {
        if (PlayerControl.LocalPlayer == null || !AmongUsClient.Instance.AmHost) return;

        if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
        {
            HandleTouchDrag();
        }
        else
        {
            HandleMouseDrag();
        }

        HandleOtherInputs();
    }

    private void HandleOtherInputs()
    {
        if (selectedPlayer == null) return;

        if (selectedPlayer is PlayerControl pc)
        { 
            if (Input.GetKeyDown(KeyCode.Equals))
            {
                lastPlayerScale += 0.1f;
                pc.RpcSetPlayerScale(lastPlayerScale);
            }
            if (Input.GetKeyDown(KeyCode.Minus))
            {
                lastPlayerScale -= 0.1f;
                pc.RpcSetPlayerScale(lastPlayerScale);
            }
        }
    }

    private void HandleMouseDrag()
    {
        isDragging = Input.GetMouseButton(1) && PlayerControl.LocalPlayer.CanMove;

        if (Input.GetMouseButtonDown(1))
        {
            StartDragging(Camera.main.ScreenToWorldPoint(Input.mousePosition));
        }

        if (Input.GetMouseButtonUp(1))
        {
            StopDragging();
        }

        if (isDragging && selectedPlayer != null && tpInterval.ShouldInvoke())
        {
            DragObject(Camera.main.ScreenToWorldPoint(Input.mousePosition));
        }
    }

    private void HandleTouchDrag()
    {
        if (Input.touchCount > 0)
        {
            foreach (Touch touch in Input.touches)
            {
                Vector2 touchPosition = Camera.main.ScreenToWorldPoint(touch.position);

                switch (touch.phase)
                {
                    case TouchPhase.Began:
                        if (activeTouchId == -1)
                        {
                            StartDragging(touchPosition, touch.fingerId);
                        }
                        break;

                    case TouchPhase.Moved:
                    case TouchPhase.Stationary:
                        if (isDragging && selectedPlayer != null && touch.fingerId == activeTouchId && tpInterval.ShouldInvoke())
                        {
                            DragObject(touchPosition);
                        }
                        break;

                    case TouchPhase.Ended:
                    case TouchPhase.Canceled:
                        if (touch.fingerId == activeTouchId)
                        {
                            StopDragging();
                        }
                        break;
                }
            }
        }
    }

    private void StartDragging(Vector3 position, int touchId = -1)
    {
        Vector3 mousePosition = position;
        mousePosition.z = 0f;

        Collider2D[] hitColliders = Physics2D.OverlapPointAll(mousePosition);

        foreach (Collider2D hitCollider in hitColliders)
        {
            PlayerControl playerControl = hitCollider.GetComponent<PlayerControl>();
            if (playerControl != null && AmongUsClient.Instance.AmHost)
            {
                playerControl.myRend.material.SetFloat("_Outline", 1f);
                playerControl.myRend.material.SetColor("_OutlineColor", Color.white);
                selectedPlayer = playerControl;
                lastPlayerScale = playerControl.transform.localScale.x;
                isDragging = true;
                activeTouchId = touchId;
                break;
            }
        }
    }

    private void StopDragging()
    {
        try
        {
            if (selectedPlayer != null)
            {
                if (selectedPlayer is PlayerControl pc)
                {
                    pc.myRend.material.SetFloat("_Outline", 0f);
                }
            }
        }
        catch { }

        selectedPlayer = null;
        isDragging = false;
        activeTouchId = -1;
    }

    private void DragObject(Vector2 position)
    {
        if (selectedPlayer is PlayerControl pc)
        {
            pc.NetTransform.RpcTeleport(position);
        }
    }
}