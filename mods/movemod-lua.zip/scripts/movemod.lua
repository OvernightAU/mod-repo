
local go = CreateGameObject("MoveMod")
DontDestroyOnLoad(go)

local luaBehaviourType = luaType("LuaBehaviour")
local luaBehaviour = AddComponent(go, luaBehaviourType)

local movemod = {
    isDragging = false,
    selectedPlayer = nil,

    Start = function(self)
        print("Initialized!")
    end,
    StartDragging = function(self, player)
        if (player == nil) then
            return
        end
        player.myRend.material.SetFloat("_Outline", 1)
        player.myRend.material.SetColor("_OutlineColor", WHITE)
        selectedPlayer = player
    end,
    StopDragging = function(self)
        if (selectedPlayer == nil) then
            return
        end
        selectedPlayer.myRend.material.SetFloat("_Outline", 0)
        selectedPlayer = nil
    end,
    Update = function(self)
        if (AmHost() == false) then
            return
        end

        local localPlayer = GetLocalPlayer()

        if (localPlayer == nil) then
            return
        end

        isDragging = GetMouseButton(0)

        if GetMouseButtonDown(0) then
            local mouseScreen = GetMousePosition()
            local worldPos = GetWorldPosition(mouseScreen)
            local world2D = Vector3ToVector2(worldPos)
            local colliders = OverlapPointAll(world2D)
            
            for i, c in ipairs(colliders) do
                local player = GetComponent(c, luaType("PlayerControl"))
                if player ~= nil then
                    self:StartDragging(player)
                    break
                end
            end
        end

        if (GetMouseButtonUp(0)) then
            self:StopDragging()
        end

        if (isDragging and selectedPlayer ~= nil) then
            local mouseScreen = GetMousePosition()
            local worldPos = GetWorldPosition(mouseScreen)
            selectedPlayer.transform.position = worldPos
        end
    end,
    FixedUpdate = function(self)
        if (isDragging == false or selectedPlayer == nil) then
            return
        end

        local mouseScreen = GetMousePosition()
        local worldPos = GetWorldPosition(mouseScreen)
        local world2D = Vector3ToVector2(worldPos)
        selectedPlayer.NetTransform.RpcSnapTo(world2D)
    end
}

luaBehaviour:Init(movemod)