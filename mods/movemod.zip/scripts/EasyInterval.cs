public enum UpdateType
{
    Default,
    Fixed,
    Late,
}


public class EasyInterval
{
    public float intervalInSeconds;
    private float timer;
    private readonly UpdateType updateType;

    public EasyInterval(float intervalInSeconds, UpdateType updateType)
    {
        this.intervalInSeconds = intervalInSeconds;
        this.updateType = updateType;
        this.timer = 0f;
    }

    public bool ShouldInvoke()
    {
        float deltaTime = GetDeltaTime();
        timer += deltaTime;
        if (timer >= intervalInSeconds)
        {
            timer = 0f;
            return true;
        }
        return false;
    }

    private float GetDeltaTime()
    {
        switch (updateType)
        {
            case UpdateType.Fixed:
                return Time.fixedDeltaTime;
            default:
                return Time.deltaTime;
        }
    }
}