﻿using UnityEngine;
using Hazel;
using HarmonyLib;

public class DynamicCode
{
    private Harmony harmony;

    public void Execute()
    {
        GameObject moveMod = new GameObject("MoveModInstance");
        Object.DontDestroyOnLoad(moveMod);
        moveMod.AddComponent<MoveWithMouse>();

        try
        {
            harmony = new Harmony("com.pietro.zoom");
            harmony.PatchAll();
        }
        catch(System.Exception ex)
        {
            Debug.Log(ex);
        }

        MUEventManager.Instance.OnEventCalled("PlayerControl::HandleRpc::Postfix", (parameters) =>
        {
            if ((byte)parameters[1] == 69)
            {
                Debug.Log("hi");
            }
        });
    }
}