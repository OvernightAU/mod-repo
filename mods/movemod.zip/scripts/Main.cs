﻿using UnityEngine;
using Hazel;
using HarmonyLib;
using System.Collections;
using UnityEngine.SceneManagement;
using TMPro;

public class DynamicCode
{
    private Harmony harmony;
    private bool failed = false;

    public void Execute()
    {
        GameObject moveMod = new GameObject("MoveModInstance");
        Object.DontDestroyOnLoad(moveMod);
        moveMod.AddComponent<MoveWithMouse>();

        try
        {
            harmony = new Harmony("com.pietro.zoom");
            harmony.PatchAll();
        }
        catch (System.Exception ex)
        {
            Debug.Log(ex);
            failed = true;
        }

        MUEventManager.Instance.OnEventCalled("PlayerControl::HandleRpc::Postfix", (parameters) =>
        {
            if ((byte)parameters[1] == 69)
            {
                Debug.Log("hi");
            }
        });

        if (SceneManager.GetActiveScene().name == "MainMenu")
        {
            AddWaterMrk();
        }

        SceneManager.activeSceneChanged += delegate (Scene oldScene, Scene scene)
        {
            if (scene.name == "MainMenu")
            {
                AddWaterMrk();
            }
        };
    }

    internal void AddWaterMrk()
    {
        Coroutines.Instance.StartCoroutine(AddWaterMrkCoroutine());
    }

    private IEnumerator AddWaterMrkCoroutine()
    {
        yield return new WaitForSeconds(0.05f); // Wait for code execution

        string text;

        if (failed)
        {
            text = "Zoom patch failed to be applied :(\nPlease send logs.";
        }
        else
        { 
            text = "Zoom patch was applied succesfully :)";
        }

        GameObject.Find("VersionShower").GetComponent<TextMeshPro>().text += $"\n<size=70%>{text}</size>";
    }
}